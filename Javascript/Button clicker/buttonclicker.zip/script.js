

function replace(button) {
if (button.innerText == "Login")
    button.innerText = "Logout";
 else(
     button.innerText="Login");

 }


function hide(element){
element.remove();
}


function over(one){
    one.style.backgroundColor = "red";
   
}

function out(one){
        one.style.backgroundColor = "yellow";
    }

    
