﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

int mosha = 18;

if (mosha == 18){
    Console.WriteLine("Ju tashme mund te pini alkol");
}
else if (mosha < 18){
    Console.WriteLine("Jeni shume i vogel per te pire");
}
else{
    Console.WriteLine("Ju jeni i rritur keshtu qe mund te pini alkol");
}

Console.WriteLine("Hello World");